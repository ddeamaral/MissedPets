﻿using System;
using Neo4j.Driver.V1;
using System.Threading.Tasks;

namespace MissingPets.Data.Graph
{
    public class GraphDriver : IDisposable
    {

        private readonly Neo4j.Driver.V1.IDriver driver;

        public GraphDriver(string uri, string user, string password)
        {
            driver = GraphDatabase.Driver(uri, AuthTokens.Basic(user, password));
        }
        // TODO: Figure out how to connect to bolt://localhost:7687. (What creds to use)

        public async void Fetch<T>(string message)
        {
            using (var session = driver.Session(AccessMode.Read))
            {
                var greeting = await session.WriteTransactionAsync(tx =>
                {
                    var result = tx.RunAsync("", new { message });


                    return Task.Run(result.As<T>);
                });

                
            }
        }

        public void Dispose()
        {
            driver.Dispose();
        }

    }

    
}
