using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MissingPets.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
